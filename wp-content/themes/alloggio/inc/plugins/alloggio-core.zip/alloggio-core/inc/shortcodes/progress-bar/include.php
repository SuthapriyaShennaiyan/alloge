<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/progress-bar/progress-bar.php';