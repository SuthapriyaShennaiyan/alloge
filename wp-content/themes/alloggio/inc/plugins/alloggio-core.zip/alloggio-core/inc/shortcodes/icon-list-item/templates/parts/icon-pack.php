<?php

if ( $icon_type == 'icon-pack' ) {
	echo AlloggioCoreIconShortcode::call_shortcode( $icon_params );
}