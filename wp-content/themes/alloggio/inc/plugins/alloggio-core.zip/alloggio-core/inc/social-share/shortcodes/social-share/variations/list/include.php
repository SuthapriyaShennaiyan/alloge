<?php

include_once ALLOGGIO_CORE_INC_PATH . '/social-share/shortcodes/social-share/variations/list/helper.php';