<?php

include_once ALLOGGIO_CORE_INC_PATH . '/spinner/layouts/two-rotating-circles/helper.php';