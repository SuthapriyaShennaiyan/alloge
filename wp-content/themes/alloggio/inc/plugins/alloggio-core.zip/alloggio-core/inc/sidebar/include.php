<?php

include_once ALLOGGIO_CORE_INC_PATH . '/sidebar/helper.php';
include_once ALLOGGIO_CORE_INC_PATH . '/sidebar/dashboard/admin/sidebar-options.php';
include_once ALLOGGIO_CORE_INC_PATH . '/sidebar/dashboard/meta-box/sidebar-meta-box.php';