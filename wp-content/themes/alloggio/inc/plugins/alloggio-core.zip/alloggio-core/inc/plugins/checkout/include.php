<?php

include_once ALLOGGIO_CORE_PLUGINS_PATH . '/checkout/helper.php';
include_once ALLOGGIO_CORE_PLUGINS_PATH . '/checkout/checkout.php';