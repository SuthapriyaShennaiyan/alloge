<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/highlight/highlight.php';