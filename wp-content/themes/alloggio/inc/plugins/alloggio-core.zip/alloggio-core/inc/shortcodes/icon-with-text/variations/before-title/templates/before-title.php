<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-m-content">
		<?php alloggio_core_template_part( 'shortcodes/icon-with-text/variations/before-title', 'templates/parts/title', '', $params ) ?>
		<?php alloggio_core_template_part( 'shortcodes/icon-with-text', 'templates/parts/text', '', $params ) ?>
	</div>
</div>