<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/button/widget/button.php';