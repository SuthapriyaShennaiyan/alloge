<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php alloggio_core_template_part( 'shortcodes/video-button', 'templates/parts/image', '', $params ) ?>
	<?php alloggio_core_template_part( 'shortcodes/video-button', 'templates/parts/button', '', $params ) ?>
</div>