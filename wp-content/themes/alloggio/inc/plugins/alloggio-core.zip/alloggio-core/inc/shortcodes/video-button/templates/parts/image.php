<?php if ( ! empty( $video_link ) ) : ?>
    <div class="qodef-m-image">
		<?php echo wp_get_attachment_image( $video_image, 'full' ); ?>
    </div>
<?php endif; ?>