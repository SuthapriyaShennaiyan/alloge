<?php

include_once ALLOGGIO_CORE_INC_PATH . '/back-to-top/helper.php';
include_once ALLOGGIO_CORE_INC_PATH . '/back-to-top/dashboard/admin/back-to-top-options.php';