<?php

include_once ALLOGGIO_CORE_INC_PATH . '/roles/helper.php';
include_once ALLOGGIO_CORE_INC_PATH . '/roles/administrator/helper.php';