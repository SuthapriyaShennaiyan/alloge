<?php

include_once ALLOGGIO_CORE_INC_PATH . '/content/helper.php';