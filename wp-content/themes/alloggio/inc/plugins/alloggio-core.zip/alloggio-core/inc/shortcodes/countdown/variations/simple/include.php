<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/countdown/variations/simple/helper.php';