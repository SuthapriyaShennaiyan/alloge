<div class="qodef-m-two-rotating-circles">
	<div class="qodef-m-circle qodef-circle--1"></div>
	<div class="qodef-m-circle qodef-circle--2"></div>
</div>