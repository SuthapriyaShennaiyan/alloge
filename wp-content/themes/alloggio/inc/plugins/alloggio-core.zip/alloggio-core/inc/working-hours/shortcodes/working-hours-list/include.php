<?php

include_once ALLOGGIO_CORE_INC_PATH . '/working-hours/shortcodes/working-hours-list/working-hours-list.php';