<div class="qodef-m-five-rotating-circles">
	<div class="qodef-m-circle-item qodef-item--1 qodef-e">
		<div class="qodef-e-circle qodef-circle--1"></div>
		<div class="qodef-e-circle qodef-circle--2"></div>
		<div class="qodef-e-circle qodef-circle--3"></div>
		<div class="qodef-e-circle qodef-circle--4"></div>
	</div>
	<div class="qodef-m-circle-item qodef-item--2 qodef-e">
		<div class="qodef-e-circle qodef-circle--1"></div>
		<div class="qodef-e-circle qodef-circle--2"></div>
		<div class="qodef-e-circle qodef-circle--3"></div>
		<div class="qodef-e-circle qodef-circle--4"></div>
	</div>
	<div class="qodef-m-circle-item qodef-item--3 qodef-e">
		<div class="qodef-e-circle qodef-circle--1"></div>
		<div class="qodef-e-circle qodef-circle--2"></div>
		<div class="qodef-e-circle qodef-circle--3"></div>
		<div class="qodef-e-circle qodef-circle--4"></div>
	</div>
</div>