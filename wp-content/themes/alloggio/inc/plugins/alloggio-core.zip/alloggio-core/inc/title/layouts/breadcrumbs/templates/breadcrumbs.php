<?php
// Load title image template
alloggio_core_get_page_title_image(); ?>
<div class="qodef-m-content <?php echo esc_attr( alloggio_core_get_page_title_content_classes() ); ?>">
	<?php
	// Load breadcrumbs template
	alloggio_core_breadcrumbs(); ?>
</div>

