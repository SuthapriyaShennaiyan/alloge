<?php

include_once ALLOGGIO_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/standard/standard.php';