<?php if ( ! empty( $content ) ) { ?>
	<div class="qodef-m-content"><?php echo do_shortcode( $content ); ?></div>
<?php } ?>