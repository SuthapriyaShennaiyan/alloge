<div class="qodef-m-pulses">
	<div class="qodef-m-pulse qodef-pulse--1"></div>
	<div class="qodef-m-pulse qodef-pulse--2"></div>
</div>