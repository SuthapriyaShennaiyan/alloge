<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/icon-list-item/widget/icon-list-item.php';