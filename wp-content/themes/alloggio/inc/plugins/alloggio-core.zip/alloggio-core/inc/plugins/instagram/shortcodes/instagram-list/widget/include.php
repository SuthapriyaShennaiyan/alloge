<?php

include_once ALLOGGIO_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/instagram-list.php';