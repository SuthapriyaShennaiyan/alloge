<?php

if ( ! empty( $subtitle ) ) { ?>
	<<?php echo esc_attr( $subtitle_tag ); ?> class="qodef-m-subtitle"><?php echo esc_html( $subtitle ); ?></<?php echo esc_attr( $subtitle_tag ); ?>>
<?php } ?>