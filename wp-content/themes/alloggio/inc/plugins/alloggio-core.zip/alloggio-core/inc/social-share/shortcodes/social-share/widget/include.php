<?php

include_once ALLOGGIO_CORE_INC_PATH . '/social-share/shortcodes/social-share/widget/social-share.php';