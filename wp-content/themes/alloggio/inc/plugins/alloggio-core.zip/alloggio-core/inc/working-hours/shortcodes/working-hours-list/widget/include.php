<?php

include_once ALLOGGIO_CORE_INC_PATH . '/working-hours/shortcodes/working-hours-list/widget/working-hours-list.php';