(function ($) {
    "use strict";

	qodefCore.shortcodes.alloggio_core_video_button = {};
    qodefCore.shortcodes.alloggio_core_video_button.qodefMagnificPopup = qodef.qodefMagnificPopup;

})(jQuery);