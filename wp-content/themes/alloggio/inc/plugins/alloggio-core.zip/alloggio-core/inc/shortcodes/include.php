<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/helper.php';
include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/shortcodes.php';