<?php

include_once ALLOGGIO_CORE_SHORTCODES_PATH . '/pricing-table/variations/standard/helper.php';