<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-action-link qodef--cart qodef-button qodef-html--link qodef-layout--outlined"><?php esc_html_e( 'View Cart', 'alloggio-core' ); ?></a>
	<a itemprop="url" href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="qodef-m-action-link qodef--checkout qodef-button qodef-html--link qodef-layout--outlined"><?php esc_html_e( 'Checkout', 'alloggio-core' ); ?></a>
</div>