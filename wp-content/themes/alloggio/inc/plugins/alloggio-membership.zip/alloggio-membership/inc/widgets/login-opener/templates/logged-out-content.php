<a href="#" class="qodef-login-opener">
	<span class="qodef-login-opener-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="18px" viewBox="0 0 26.5 33.8" xml:space="preserve"><g><path d="M25.8,27.7c0-6.9-5.6-12.5-12.5-12.5S0.8,20.8,0.8,27.7v5.3h25V27.7z"/><circle cx="13.3" cy="8" r="7.2"/></g></svg></span>
	<span class="qodef-login-opener-text"><?php esc_html_e( 'Sign In', 'alloggio-membership' ); ?></span>
</a>