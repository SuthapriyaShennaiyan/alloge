<?php

require_once ALLOGGIO_MEMBERSHIP_INC_PATH . '/general/register-template.php';
include_once ALLOGGIO_MEMBERSHIP_INC_PATH . '/general/helper.php';